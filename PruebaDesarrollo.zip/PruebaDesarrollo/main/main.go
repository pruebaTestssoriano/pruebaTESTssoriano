package main

import (
	"fmt"
)

func main() {

	var valor = "CADENA DE EJEMPLO"
	Translate(valor, "TEXT", "MORSE")


	fmt.Println("Saul Alfredo Soriano")

}

func Translate(TextoATraducir string,formatoOriginal string, formatoDestino string){

	var T = len(TextoATraducir)
	fmt.Println("T: ", T)
	var TEXTO [150]string

	for i := 0; i < len(TextoATraducir); i++{

		TEXTO[i] = MorseCodigo(TextoATraducir[i:i+1])
	}

	fmt.Println("Resultado de traduccion: ", TEXTO)
}

func MorseCodigo(Letra string) (valor string){
	var codigo[27][2]string
	codigo[0][0] = "A"
	codigo[0][1] = ".-"
	codigo[1][0] = "B"
	codigo[1][1] = "-..."
	codigo[2][0] = "C"
	codigo[2][1] = "-.-."
	codigo[3][0] = "D"
	codigo[3][1] = "-.."
	codigo[4][0] = "E"
	codigo[4][1] = "."
	codigo[5][0] = "F"
	codigo[5][1] = "..-."
	codigo[6][0] = "G"
	codigo[6][1] = "--."
	codigo[7][0] = "H"
	codigo[7][1] = "...."
	codigo[8][0] = "I"
	codigo[8][1] = ".."
	codigo[9][0] = "J"
	codigo[9][1] = ".---"
	codigo[10][0] = "K"
	codigo[10][1] = "-.-"
	codigo[11][0] = "L"
	codigo[11][1] = ".-.."
	codigo[12][0] = "M"
	codigo[12][1] = "--"
	codigo[13][0] = "N"
	codigo[13][1] = "-."
	codigo[14][0] = "O"
	codigo[14][1] = "---"
	codigo[15][0] = "P"
	codigo[15][1] = ".--."
	codigo[16][0] = "Q"
	codigo[16][1] = "--.-"
	codigo[17][0] = "R"
	codigo[17][1] = ".-."
	codigo[18][0] = "S"
	codigo[18][1] = "..."
	codigo[19][0] = "T"
	codigo[19][1] = "-"
	codigo[20][0] = "U"
	codigo[20][1] = "..-"
	codigo[21][0] = "V"
	codigo[21][1] = "...-"
	codigo[22][0] = "W"
	codigo[22][1] = ".--"
	codigo[23][0] = "X"
	codigo[23][1] = "-..-"
	codigo[24][0] = "Y"
	codigo[24][1] = "-.--"
	codigo[25][0] = "Z"
	codigo[25][1] = "--.."
	codigo[26][0] = " "
	codigo[26][1] = "   "

	for i := 0; i < 27; i++{

		if Letra == codigo[i][0] {

			return codigo[i][1]
		}
	}

	return "E"

}

